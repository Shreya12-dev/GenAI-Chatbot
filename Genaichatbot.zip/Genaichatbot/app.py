import streamlit as st
from langchain.vectorstores import Qdrant
from langchain.embeddings import HuggingFaceEmbeddings
from langchain_community.chat_message_histories import PostgresChatMessageHistory
from langchain.memory import ConversationBufferMemory
from langchain.chains import RetrievalQA
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_community.vectorstores import Qdrant as QdrantCommunity
import os

# Initialize environment variables or keys
os.environ["GOOGLE_API_KEY"] = "your_google_api_key_here"

# Initialize embeddings
embeddings = HuggingFaceEmbeddings()

# Load Qdrant vectorstore (change the path and settings as needed)
db = QdrantCommunity(
    collection_name="ragbot",
    embeddings=embeddings,
    path="./qdrant_data"
)
retriever = db.as_retriever()

# Setup LangChain memory (optional)
history = PostgresChatMessageHistory(
    connection_string="postgresql://user:password@localhost/chat_memory",
    session_id="session1"
)
memory = ConversationBufferMemory(
    memory_key="chat_history",
    chat_memory=history,
    return_messages=True
)

# Initialize Gemini LLM
llm = ChatGoogleGenerativeAI(model="gemini-pro")

# Setup RetrievalQA chain
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever,
    memory=memory,
    return_source_documents=True
)

# Streamlit UI
st.set_page_config(page_title="GenAI RAG Chatbot")
st.title("GenAI Chatbot with RAG")

query = st.text_input("Ask your question:")
if query:
    response = qa_chain.run(query)
    st.write("Response:", response)